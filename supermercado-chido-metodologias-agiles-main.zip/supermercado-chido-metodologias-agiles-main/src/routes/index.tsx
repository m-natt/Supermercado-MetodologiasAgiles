import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Supermercado chido :3 — Supermercado en línea" },
      { name: "description", content: "Frutas, verduras, lácteos y despensa con entrega a domicilio." },
      { property: "og:title", content: "Supermercado chido :3 — Supermercado en línea" },
      { property: "og:description", content: "Haz tu súper en línea: frescos, despensa y más." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type P = { id: number; name: string; price: number; cat: string; emoji: string; unit: string };
const PRODUCTS: P[] = [
  { id: 1, name: "Plátano", price: 24, cat: "Frutas y verduras", emoji: "🍌", unit: "kg" },
  { id: 2, name: "Manzana roja", price: 49, cat: "Frutas y verduras", emoji: "🍎", unit: "kg" },
  { id: 3, name: "Aguacate Hass", price: 69, cat: "Frutas y verduras", emoji: "🥑", unit: "kg" },
  { id: 4, name: "Jitomate", price: 32, cat: "Frutas y verduras", emoji: "🍅", unit: "kg" },
  { id: 5, name: "Leche entera", price: 28, cat: "Lácteos", emoji: "🥛", unit: "1 L" },
  { id: 6, name: "Queso fresco", price: 85, cat: "Lácteos", emoji: "🧀", unit: "400 g" },
  { id: 7, name: "Huevo blanco", price: 62, cat: "Lácteos", emoji: "🥚", unit: "18 pzas" },
  { id: 8, name: "Pan de caja", price: 45, cat: "Panadería", emoji: "🍞", unit: "680 g" },
  { id: 9, name: "Croissant", price: 18, cat: "Panadería", emoji: "🥐", unit: "pza" },
  { id: 10, name: "Pechuga de pollo", price: 139, cat: "Carnes", emoji: "🍗", unit: "kg" },
  { id: 11, name: "Bistec de res", price: 219, cat: "Carnes", emoji: "🥩", unit: "kg" },
  { id: 12, name: "Arroz", price: 34, cat: "Despensa", emoji: "🍚", unit: "1 kg" },
  { id: 13, name: "Pasta", price: 16, cat: "Despensa", emoji: "🍝", unit: "200 g" },
  { id: 14, name: "Café molido", price: 115, cat: "Despensa", emoji: "☕", unit: "400 g" },
  { id: 15, name: "Agua natural", price: 14, cat: "Bebidas", emoji: "💧", unit: "1.5 L" },
  { id: 16, name: "Jugo de naranja", price: 38, cat: "Bebidas", emoji: "🧃", unit: "1 L" },
];
const CATS = ["Todo", ...Array.from(new Set(PRODUCTS.map((p) => p.cat)))];
const money = (n: number) => `$${n.toFixed(2)}`;

function Index() {
  const [cat, setCat] = useState("Todo");
  const [q, setQ] = useState("");
  const [cart, setCart] = useState<Record<number, number>>({});
  const [open, setOpen] = useState(false);
  const [done, setDone] = useState(false);

  const list = useMemo(
    () => PRODUCTS.filter((p) => (cat === "Todo" || p.cat === cat) && p.name.toLowerCase().includes(q.toLowerCase())),
    [cat, q],
  );
  const items = PRODUCTS.filter((p) => cart[p.id]);
  const count = items.reduce((s, p) => s + (cart[p.id] ?? 0), 0);
  const total = items.reduce((s, p) => s + (cart[p.id] ?? 0) * p.price, 0);
  const add = (id: number, d: number) =>
    setCart((c) => {
      const n = { ...c, [id]: (c[id] || 0) + d };
      if ((n[id] ?? 0) <= 0) delete n[id];
      return n;
    });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 bg-primary text-primary-foreground shadow">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3">
          <div className="text-2xl font-black tracking-tight">🛒 Supermercado chido :3</div>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar productos…"
            className="flex-1 rounded-full bg-background px-4 py-2 text-foreground outline-none"
          />
          <button onClick={() => setOpen(true)} className="rounded-full bg-accent px-4 py-2 font-bold text-accent-foreground">
            Carrito ({count})
          </button>
        </div>
      </header>

      <section className="bg-secondary">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <p className="text-sm font-bold uppercase tracking-widest text-primary">Ofertas de la semana</p>
          <h1 className="mt-2 text-4xl font-black text-secondary-foreground md:text-5xl">Lo fresco, directo a tu puerta</h1>
          <p className="mt-2 text-muted-foreground">Envío gratis en compras mayores a $500.</p>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="mb-6 flex flex-wrap gap-2">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${cat === c ? "border-primary bg-primary text-primary-foreground" : "bg-card text-foreground"}`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {list.map((p) => (
            <div key={p.id} className="flex flex-col rounded-xl border bg-card p-4">
              <div className="flex h-28 items-center justify-center rounded-lg bg-muted text-6xl">{p.emoji}</div>
              <p className="mt-3 text-xs text-muted-foreground">{p.cat}</p>
              <h3 className="font-bold text-card-foreground">{p.name}</h3>
              <p className="text-xs text-muted-foreground">{p.unit}</p>
              <p className="mt-1 text-lg font-black text-primary">{money(p.price)}</p>
              {cart[p.id] ? (
                <div className="mt-auto flex items-center justify-between rounded-full bg-secondary pt-0">
                  <button onClick={() => add(p.id, -1)} className="px-4 py-2 font-bold">−</button>
                  <span className="font-bold">{cart[p.id]}</span>
                  <button onClick={() => add(p.id, 1)} className="px-4 py-2 font-bold">+</button>
                </div>
              ) : (
                <button onClick={() => add(p.id, 1)} className="mt-auto rounded-full bg-primary py-2 font-bold text-primary-foreground">
                  Agregar
                </button>
              )}
            </div>
          ))}
          {!list.length && <p className="text-muted-foreground">No encontramos productos.</p>}
        </div>
      </main>

      {open && (
        <div className="fixed inset-0 z-20 flex justify-end bg-foreground/40" onClick={() => setOpen(false)}>
          <aside className="flex h-full w-full max-w-sm flex-col bg-card p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black">Tu carrito</h2>
              <button onClick={() => setOpen(false)} className="text-2xl">×</button>
            </div>
            {done ? (
              <div className="m-auto text-center">
                <div className="text-6xl">✅</div>
                <p className="mt-2 font-bold">¡Pedido confirmado!</p>
                <p className="text-sm text-muted-foreground">Llegará en 45 minutos (simulado).</p>
              </div>
            ) : (
              <>
                <div className="mt-4 flex-1 space-y-3 overflow-auto">
                  {!items.length && <p className="text-muted-foreground">Tu carrito está vacío.</p>}
                  {items.map((p) => (
                    <div key={p.id} className="flex items-center gap-3">
                      <span className="text-3xl">{p.emoji}</span>
                      <div className="flex-1">
                        <p className="font-semibold">{p.name}</p>
                        <p className="text-xs text-muted-foreground">{cart[p.id]} × {money(p.price)}</p>
                      </div>
                      <button onClick={() => add(p.id, -1)} className="px-2 font-bold">−</button>
                      <button onClick={() => add(p.id, 1)} className="px-2 font-bold">+</button>
                    </div>
                  ))}
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between font-black"><span>Total</span><span>{money(total)}</span></div>
                  <button
                    disabled={!items.length}
                    onClick={() => { setDone(true); setCart({}); }}
                    className="mt-3 w-full rounded-full bg-primary py-3 font-bold text-primary-foreground disabled:opacity-50"
                  >
                    Pagar
                  </button>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
